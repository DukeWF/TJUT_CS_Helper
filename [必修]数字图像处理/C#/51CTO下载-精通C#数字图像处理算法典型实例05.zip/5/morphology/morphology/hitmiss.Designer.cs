﻿namespace morphology
{
    partial class hitmiss
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.start = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.hit8 = new System.Windows.Forms.Button();
            this.hit7 = new System.Windows.Forms.Button();
            this.hit6 = new System.Windows.Forms.Button();
            this.hit5 = new System.Windows.Forms.Button();
            this.hit4 = new System.Windows.Forms.Button();
            this.hit3 = new System.Windows.Forms.Button();
            this.hit2 = new System.Windows.Forms.Button();
            this.hit1 = new System.Windows.Forms.Button();
            this.hit0 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.miss8 = new System.Windows.Forms.Button();
            this.miss7 = new System.Windows.Forms.Button();
            this.miss6 = new System.Windows.Forms.Button();
            this.miss5 = new System.Windows.Forms.Button();
            this.miss4 = new System.Windows.Forms.Button();
            this.miss3 = new System.Windows.Forms.Button();
            this.miss2 = new System.Windows.Forms.Button();
            this.miss1 = new System.Windows.Forms.Button();
            this.miss0 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(55, 176);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(75, 23);
            this.start.TabIndex = 0;
            this.start.Text = "确定";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(203, 176);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(75, 23);
            this.close.TabIndex = 1;
            this.close.Text = "退出";
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.hit8);
            this.groupBox1.Controls.Add(this.hit7);
            this.groupBox1.Controls.Add(this.hit6);
            this.groupBox1.Controls.Add(this.hit5);
            this.groupBox1.Controls.Add(this.hit4);
            this.groupBox1.Controls.Add(this.hit3);
            this.groupBox1.Controls.Add(this.hit2);
            this.groupBox1.Controls.Add(this.hit1);
            this.groupBox1.Controls.Add(this.hit0);
            this.groupBox1.Location = new System.Drawing.Point(25, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(120, 120);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "击中结构元素";
            // 
            // hit8
            // 
            this.hit8.BackColor = System.Drawing.Color.White;
            this.hit8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hit8.Location = new System.Drawing.Point(68, 68);
            this.hit8.Name = "hit8";
            this.hit8.Size = new System.Drawing.Size(20, 20);
            this.hit8.TabIndex = 9;
            this.hit8.UseVisualStyleBackColor = false;
            this.hit8.Click += new System.EventHandler(this.hit8_Click);
            // 
            // hit7
            // 
            this.hit7.BackColor = System.Drawing.Color.White;
            this.hit7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hit7.Location = new System.Drawing.Point(49, 68);
            this.hit7.Name = "hit7";
            this.hit7.Size = new System.Drawing.Size(20, 20);
            this.hit7.TabIndex = 8;
            this.hit7.UseVisualStyleBackColor = false;
            this.hit7.Click += new System.EventHandler(this.hit7_Click);
            // 
            // hit6
            // 
            this.hit6.BackColor = System.Drawing.Color.White;
            this.hit6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hit6.Location = new System.Drawing.Point(30, 68);
            this.hit6.Name = "hit6";
            this.hit6.Size = new System.Drawing.Size(20, 20);
            this.hit6.TabIndex = 7;
            this.hit6.UseVisualStyleBackColor = false;
            this.hit6.Click += new System.EventHandler(this.hit6_Click);
            // 
            // hit5
            // 
            this.hit5.BackColor = System.Drawing.Color.White;
            this.hit5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hit5.Location = new System.Drawing.Point(68, 49);
            this.hit5.Name = "hit5";
            this.hit5.Size = new System.Drawing.Size(20, 20);
            this.hit5.TabIndex = 6;
            this.hit5.UseVisualStyleBackColor = false;
            this.hit5.Click += new System.EventHandler(this.hit5_Click);
            // 
            // hit4
            // 
            this.hit4.BackColor = System.Drawing.Color.White;
            this.hit4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hit4.Location = new System.Drawing.Point(49, 49);
            this.hit4.Name = "hit4";
            this.hit4.Size = new System.Drawing.Size(20, 20);
            this.hit4.TabIndex = 5;
            this.hit4.UseVisualStyleBackColor = false;
            this.hit4.Click += new System.EventHandler(this.hit4_Click);
            // 
            // hit3
            // 
            this.hit3.BackColor = System.Drawing.Color.White;
            this.hit3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hit3.Location = new System.Drawing.Point(30, 49);
            this.hit3.Name = "hit3";
            this.hit3.Size = new System.Drawing.Size(20, 20);
            this.hit3.TabIndex = 4;
            this.hit3.UseVisualStyleBackColor = false;
            this.hit3.Click += new System.EventHandler(this.hit3_Click);
            // 
            // hit2
            // 
            this.hit2.BackColor = System.Drawing.Color.White;
            this.hit2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hit2.Location = new System.Drawing.Point(68, 30);
            this.hit2.Name = "hit2";
            this.hit2.Size = new System.Drawing.Size(20, 20);
            this.hit2.TabIndex = 3;
            this.hit2.UseVisualStyleBackColor = false;
            this.hit2.Click += new System.EventHandler(this.hit2_Click);
            // 
            // hit1
            // 
            this.hit1.BackColor = System.Drawing.Color.White;
            this.hit1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hit1.Location = new System.Drawing.Point(49, 30);
            this.hit1.Name = "hit1";
            this.hit1.Size = new System.Drawing.Size(20, 20);
            this.hit1.TabIndex = 1;
            this.hit1.UseVisualStyleBackColor = false;
            this.hit1.Click += new System.EventHandler(this.hit1_Click);
            // 
            // hit0
            // 
            this.hit0.BackColor = System.Drawing.Color.White;
            this.hit0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hit0.Location = new System.Drawing.Point(30, 30);
            this.hit0.Name = "hit0";
            this.hit0.Size = new System.Drawing.Size(20, 20);
            this.hit0.TabIndex = 0;
            this.hit0.UseVisualStyleBackColor = false;
            this.hit0.Click += new System.EventHandler(this.hit0_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.miss8);
            this.groupBox2.Controls.Add(this.miss7);
            this.groupBox2.Controls.Add(this.miss6);
            this.groupBox2.Controls.Add(this.miss5);
            this.groupBox2.Controls.Add(this.miss4);
            this.groupBox2.Controls.Add(this.miss3);
            this.groupBox2.Controls.Add(this.miss2);
            this.groupBox2.Controls.Add(this.miss1);
            this.groupBox2.Controls.Add(this.miss0);
            this.groupBox2.Location = new System.Drawing.Point(190, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(120, 120);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "击不中结构元素";
            // 
            // miss8
            // 
            this.miss8.BackColor = System.Drawing.Color.White;
            this.miss8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.miss8.Location = new System.Drawing.Point(68, 68);
            this.miss8.Name = "miss8";
            this.miss8.Size = new System.Drawing.Size(20, 20);
            this.miss8.TabIndex = 9;
            this.miss8.UseVisualStyleBackColor = false;
            this.miss8.Click += new System.EventHandler(this.miss8_Click);
            // 
            // miss7
            // 
            this.miss7.BackColor = System.Drawing.Color.White;
            this.miss7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.miss7.Location = new System.Drawing.Point(49, 68);
            this.miss7.Name = "miss7";
            this.miss7.Size = new System.Drawing.Size(20, 20);
            this.miss7.TabIndex = 8;
            this.miss7.UseVisualStyleBackColor = false;
            this.miss7.Click += new System.EventHandler(this.miss7_Click);
            // 
            // miss6
            // 
            this.miss6.BackColor = System.Drawing.Color.White;
            this.miss6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.miss6.Location = new System.Drawing.Point(30, 68);
            this.miss6.Name = "miss6";
            this.miss6.Size = new System.Drawing.Size(20, 20);
            this.miss6.TabIndex = 7;
            this.miss6.UseVisualStyleBackColor = false;
            this.miss6.Click += new System.EventHandler(this.miss6_Click);
            // 
            // miss5
            // 
            this.miss5.BackColor = System.Drawing.Color.White;
            this.miss5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.miss5.Location = new System.Drawing.Point(68, 49);
            this.miss5.Name = "miss5";
            this.miss5.Size = new System.Drawing.Size(20, 20);
            this.miss5.TabIndex = 6;
            this.miss5.UseVisualStyleBackColor = false;
            this.miss5.Click += new System.EventHandler(this.miss5_Click);
            // 
            // miss4
            // 
            this.miss4.BackColor = System.Drawing.Color.White;
            this.miss4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.miss4.Location = new System.Drawing.Point(49, 49);
            this.miss4.Name = "miss4";
            this.miss4.Size = new System.Drawing.Size(20, 20);
            this.miss4.TabIndex = 5;
            this.miss4.UseVisualStyleBackColor = false;
            this.miss4.Click += new System.EventHandler(this.miss4_Click);
            // 
            // miss3
            // 
            this.miss3.BackColor = System.Drawing.Color.White;
            this.miss3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.miss3.Location = new System.Drawing.Point(30, 49);
            this.miss3.Name = "miss3";
            this.miss3.Size = new System.Drawing.Size(20, 20);
            this.miss3.TabIndex = 4;
            this.miss3.UseVisualStyleBackColor = false;
            this.miss3.Click += new System.EventHandler(this.miss3_Click);
            // 
            // miss2
            // 
            this.miss2.BackColor = System.Drawing.Color.White;
            this.miss2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.miss2.Location = new System.Drawing.Point(68, 30);
            this.miss2.Name = "miss2";
            this.miss2.Size = new System.Drawing.Size(20, 20);
            this.miss2.TabIndex = 3;
            this.miss2.UseVisualStyleBackColor = false;
            this.miss2.Click += new System.EventHandler(this.miss2_Click);
            // 
            // miss1
            // 
            this.miss1.BackColor = System.Drawing.Color.White;
            this.miss1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.miss1.Location = new System.Drawing.Point(49, 30);
            this.miss1.Name = "miss1";
            this.miss1.Size = new System.Drawing.Size(20, 20);
            this.miss1.TabIndex = 1;
            this.miss1.UseVisualStyleBackColor = false;
            this.miss1.Click += new System.EventHandler(this.miss1_Click);
            // 
            // miss0
            // 
            this.miss0.BackColor = System.Drawing.Color.White;
            this.miss0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.miss0.Location = new System.Drawing.Point(30, 30);
            this.miss0.Name = "miss0";
            this.miss0.Size = new System.Drawing.Size(20, 20);
            this.miss0.TabIndex = 0;
            this.miss0.UseVisualStyleBackColor = false;
            this.miss0.Click += new System.EventHandler(this.miss0_Click);
            // 
            // hitmiss
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(337, 225);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.close);
            this.Controls.Add(this.start);
            this.Name = "hitmiss";
            this.Text = "击中击不中变换";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Button close;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button hit0;
        private System.Windows.Forms.Button hit8;
        private System.Windows.Forms.Button hit7;
        private System.Windows.Forms.Button hit6;
        private System.Windows.Forms.Button hit5;
        private System.Windows.Forms.Button hit4;
        private System.Windows.Forms.Button hit3;
        private System.Windows.Forms.Button hit2;
        private System.Windows.Forms.Button hit1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button miss8;
        private System.Windows.Forms.Button miss7;
        private System.Windows.Forms.Button miss6;
        private System.Windows.Forms.Button miss5;
        private System.Windows.Forms.Button miss4;
        private System.Windows.Forms.Button miss3;
        private System.Windows.Forms.Button miss2;
        private System.Windows.Forms.Button miss1;
        private System.Windows.Forms.Button miss0;

        private bool[] flagHit;
        private bool[] flagMiss;
    }
}