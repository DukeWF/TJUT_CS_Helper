﻿namespace smooth
{
    partial class morphologic
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.start = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.se1 = new System.Windows.Forms.Button();
            this.se2 = new System.Windows.Forms.Button();
            this.se4 = new System.Windows.Forms.Button();
            this.se3 = new System.Windows.Forms.Button();
            this.se5 = new System.Windows.Forms.Button();
            this.se10 = new System.Windows.Forms.Button();
            this.se9 = new System.Windows.Forms.Button();
            this.se8 = new System.Windows.Forms.Button();
            this.se7 = new System.Windows.Forms.Button();
            this.se6 = new System.Windows.Forms.Button();
            this.se15 = new System.Windows.Forms.Button();
            this.se14 = new System.Windows.Forms.Button();
            this.se13 = new System.Windows.Forms.Button();
            this.se12 = new System.Windows.Forms.Button();
            this.se11 = new System.Windows.Forms.Button();
            this.se20 = new System.Windows.Forms.Button();
            this.se19 = new System.Windows.Forms.Button();
            this.se18 = new System.Windows.Forms.Button();
            this.se17 = new System.Windows.Forms.Button();
            this.se16 = new System.Windows.Forms.Button();
            this.se25 = new System.Windows.Forms.Button();
            this.se24 = new System.Windows.Forms.Button();
            this.se23 = new System.Windows.Forms.Button();
            this.se22 = new System.Windows.Forms.Button();
            this.se21 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(14, 172);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(75, 23);
            this.start.TabIndex = 0;
            this.start.Text = "确定";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(107, 172);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(75, 23);
            this.close.TabIndex = 1;
            this.close.Text = "退出 ";
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "平坦结构元素：";
            // 
            // se1
            // 
            this.se1.BackColor = System.Drawing.Color.White;
            this.se1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se1.Location = new System.Drawing.Point(50, 50);
            this.se1.Name = "se1";
            this.se1.Size = new System.Drawing.Size(20, 20);
            this.se1.TabIndex = 3;
            this.se1.UseVisualStyleBackColor = false;
            this.se1.Click += new System.EventHandler(this.se1_Click);
            // 
            // se2
            // 
            this.se2.BackColor = System.Drawing.Color.White;
            this.se2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se2.Location = new System.Drawing.Point(69, 50);
            this.se2.Name = "se2";
            this.se2.Size = new System.Drawing.Size(20, 20);
            this.se2.TabIndex = 4;
            this.se2.UseVisualStyleBackColor = false;
            this.se2.Click += new System.EventHandler(this.se2_Click);
            // 
            // se4
            // 
            this.se4.BackColor = System.Drawing.Color.White;
            this.se4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se4.Location = new System.Drawing.Point(107, 50);
            this.se4.Name = "se4";
            this.se4.Size = new System.Drawing.Size(20, 20);
            this.se4.TabIndex = 6;
            this.se4.UseVisualStyleBackColor = false;
            this.se4.Click += new System.EventHandler(this.se4_Click);
            // 
            // se3
            // 
            this.se3.BackColor = System.Drawing.Color.White;
            this.se3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se3.Location = new System.Drawing.Point(88, 50);
            this.se3.Name = "se3";
            this.se3.Size = new System.Drawing.Size(20, 20);
            this.se3.TabIndex = 5;
            this.se3.UseVisualStyleBackColor = false;
            this.se3.Click += new System.EventHandler(this.se3_Click);
            // 
            // se5
            // 
            this.se5.BackColor = System.Drawing.Color.White;
            this.se5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se5.Location = new System.Drawing.Point(126, 50);
            this.se5.Name = "se5";
            this.se5.Size = new System.Drawing.Size(20, 20);
            this.se5.TabIndex = 7;
            this.se5.UseVisualStyleBackColor = false;
            this.se5.Click += new System.EventHandler(this.se5_Click);
            // 
            // se10
            // 
            this.se10.BackColor = System.Drawing.Color.White;
            this.se10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se10.Location = new System.Drawing.Point(126, 69);
            this.se10.Name = "se10";
            this.se10.Size = new System.Drawing.Size(20, 20);
            this.se10.TabIndex = 12;
            this.se10.UseVisualStyleBackColor = false;
            this.se10.Click += new System.EventHandler(this.se10_Click);
            // 
            // se9
            // 
            this.se9.BackColor = System.Drawing.Color.White;
            this.se9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se9.Location = new System.Drawing.Point(107, 69);
            this.se9.Name = "se9";
            this.se9.Size = new System.Drawing.Size(20, 20);
            this.se9.TabIndex = 11;
            this.se9.UseVisualStyleBackColor = false;
            this.se9.Click += new System.EventHandler(this.se9_Click);
            // 
            // se8
            // 
            this.se8.BackColor = System.Drawing.Color.White;
            this.se8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se8.Location = new System.Drawing.Point(88, 69);
            this.se8.Name = "se8";
            this.se8.Size = new System.Drawing.Size(20, 20);
            this.se8.TabIndex = 10;
            this.se8.UseVisualStyleBackColor = false;
            this.se8.Click += new System.EventHandler(this.se8_Click);
            // 
            // se7
            // 
            this.se7.BackColor = System.Drawing.Color.White;
            this.se7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se7.Location = new System.Drawing.Point(69, 69);
            this.se7.Name = "se7";
            this.se7.Size = new System.Drawing.Size(20, 20);
            this.se7.TabIndex = 9;
            this.se7.UseVisualStyleBackColor = false;
            this.se7.Click += new System.EventHandler(this.se7_Click);
            // 
            // se6
            // 
            this.se6.BackColor = System.Drawing.Color.White;
            this.se6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se6.Location = new System.Drawing.Point(50, 69);
            this.se6.Name = "se6";
            this.se6.Size = new System.Drawing.Size(20, 20);
            this.se6.TabIndex = 8;
            this.se6.UseVisualStyleBackColor = false;
            this.se6.Click += new System.EventHandler(this.se6_Click);
            // 
            // se15
            // 
            this.se15.BackColor = System.Drawing.Color.White;
            this.se15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se15.Location = new System.Drawing.Point(126, 88);
            this.se15.Name = "se15";
            this.se15.Size = new System.Drawing.Size(20, 20);
            this.se15.TabIndex = 17;
            this.se15.UseVisualStyleBackColor = false;
            this.se15.Click += new System.EventHandler(this.se15_Click);
            // 
            // se14
            // 
            this.se14.BackColor = System.Drawing.Color.White;
            this.se14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se14.Location = new System.Drawing.Point(107, 88);
            this.se14.Name = "se14";
            this.se14.Size = new System.Drawing.Size(20, 20);
            this.se14.TabIndex = 16;
            this.se14.UseVisualStyleBackColor = false;
            this.se14.Click += new System.EventHandler(this.se14_Click);
            // 
            // se13
            // 
            this.se13.BackColor = System.Drawing.Color.White;
            this.se13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se13.Location = new System.Drawing.Point(88, 88);
            this.se13.Name = "se13";
            this.se13.Size = new System.Drawing.Size(20, 20);
            this.se13.TabIndex = 15;
            this.se13.UseVisualStyleBackColor = false;
            this.se13.Click += new System.EventHandler(this.se13_Click);
            // 
            // se12
            // 
            this.se12.BackColor = System.Drawing.Color.White;
            this.se12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se12.Location = new System.Drawing.Point(69, 88);
            this.se12.Name = "se12";
            this.se12.Size = new System.Drawing.Size(20, 20);
            this.se12.TabIndex = 14;
            this.se12.UseVisualStyleBackColor = false;
            this.se12.Click += new System.EventHandler(this.se12_Click);
            // 
            // se11
            // 
            this.se11.BackColor = System.Drawing.Color.White;
            this.se11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se11.Location = new System.Drawing.Point(50, 88);
            this.se11.Name = "se11";
            this.se11.Size = new System.Drawing.Size(20, 20);
            this.se11.TabIndex = 13;
            this.se11.UseVisualStyleBackColor = false;
            this.se11.Click += new System.EventHandler(this.se11_Click);
            // 
            // se20
            // 
            this.se20.BackColor = System.Drawing.Color.White;
            this.se20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se20.Location = new System.Drawing.Point(126, 107);
            this.se20.Name = "se20";
            this.se20.Size = new System.Drawing.Size(20, 20);
            this.se20.TabIndex = 22;
            this.se20.UseVisualStyleBackColor = false;
            this.se20.Click += new System.EventHandler(this.se20_Click);
            // 
            // se19
            // 
            this.se19.BackColor = System.Drawing.Color.White;
            this.se19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se19.Location = new System.Drawing.Point(107, 107);
            this.se19.Name = "se19";
            this.se19.Size = new System.Drawing.Size(20, 20);
            this.se19.TabIndex = 21;
            this.se19.UseVisualStyleBackColor = false;
            this.se19.Click += new System.EventHandler(this.se19_Click);
            // 
            // se18
            // 
            this.se18.BackColor = System.Drawing.Color.White;
            this.se18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se18.Location = new System.Drawing.Point(88, 107);
            this.se18.Name = "se18";
            this.se18.Size = new System.Drawing.Size(20, 20);
            this.se18.TabIndex = 20;
            this.se18.UseVisualStyleBackColor = false;
            this.se18.Click += new System.EventHandler(this.se18_Click);
            // 
            // se17
            // 
            this.se17.BackColor = System.Drawing.Color.White;
            this.se17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se17.Location = new System.Drawing.Point(69, 107);
            this.se17.Name = "se17";
            this.se17.Size = new System.Drawing.Size(20, 20);
            this.se17.TabIndex = 19;
            this.se17.UseVisualStyleBackColor = false;
            this.se17.Click += new System.EventHandler(this.se17_Click);
            // 
            // se16
            // 
            this.se16.BackColor = System.Drawing.Color.White;
            this.se16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se16.Location = new System.Drawing.Point(50, 107);
            this.se16.Name = "se16";
            this.se16.Size = new System.Drawing.Size(20, 20);
            this.se16.TabIndex = 18;
            this.se16.UseVisualStyleBackColor = false;
            this.se16.Click += new System.EventHandler(this.se16_Click);
            // 
            // se25
            // 
            this.se25.BackColor = System.Drawing.Color.White;
            this.se25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se25.Location = new System.Drawing.Point(126, 126);
            this.se25.Name = "se25";
            this.se25.Size = new System.Drawing.Size(20, 20);
            this.se25.TabIndex = 27;
            this.se25.UseVisualStyleBackColor = false;
            this.se25.Click += new System.EventHandler(this.se25_Click);
            // 
            // se24
            // 
            this.se24.BackColor = System.Drawing.Color.White;
            this.se24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se24.Location = new System.Drawing.Point(107, 126);
            this.se24.Name = "se24";
            this.se24.Size = new System.Drawing.Size(20, 20);
            this.se24.TabIndex = 26;
            this.se24.UseVisualStyleBackColor = false;
            this.se24.Click += new System.EventHandler(this.se24_Click);
            // 
            // se23
            // 
            this.se23.BackColor = System.Drawing.Color.White;
            this.se23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se23.Location = new System.Drawing.Point(88, 126);
            this.se23.Name = "se23";
            this.se23.Size = new System.Drawing.Size(20, 20);
            this.se23.TabIndex = 25;
            this.se23.UseVisualStyleBackColor = false;
            this.se23.Click += new System.EventHandler(this.se23_Click);
            // 
            // se22
            // 
            this.se22.BackColor = System.Drawing.Color.White;
            this.se22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se22.Location = new System.Drawing.Point(69, 126);
            this.se22.Name = "se22";
            this.se22.Size = new System.Drawing.Size(20, 20);
            this.se22.TabIndex = 24;
            this.se22.UseVisualStyleBackColor = false;
            this.se22.Click += new System.EventHandler(this.se22_Click);
            // 
            // se21
            // 
            this.se21.BackColor = System.Drawing.Color.White;
            this.se21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.se21.Location = new System.Drawing.Point(50, 126);
            this.se21.Name = "se21";
            this.se21.Size = new System.Drawing.Size(20, 20);
            this.se21.TabIndex = 23;
            this.se21.UseVisualStyleBackColor = false;
            this.se21.Click += new System.EventHandler(this.se21_Click);
            // 
            // morphologic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(192, 216);
            this.ControlBox = false;
            this.Controls.Add(this.se25);
            this.Controls.Add(this.se24);
            this.Controls.Add(this.se23);
            this.Controls.Add(this.se22);
            this.Controls.Add(this.se21);
            this.Controls.Add(this.se20);
            this.Controls.Add(this.se19);
            this.Controls.Add(this.se18);
            this.Controls.Add(this.se17);
            this.Controls.Add(this.se16);
            this.Controls.Add(this.se15);
            this.Controls.Add(this.se14);
            this.Controls.Add(this.se13);
            this.Controls.Add(this.se12);
            this.Controls.Add(this.se11);
            this.Controls.Add(this.se10);
            this.Controls.Add(this.se9);
            this.Controls.Add(this.se8);
            this.Controls.Add(this.se7);
            this.Controls.Add(this.se6);
            this.Controls.Add(this.se5);
            this.Controls.Add(this.se4);
            this.Controls.Add(this.se3);
            this.Controls.Add(this.se2);
            this.Controls.Add(this.se1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.close);
            this.Controls.Add(this.start);
            this.Name = "morphologic";
            this.Text = "灰度形态学滤波";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Button close;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button se1;
        private System.Windows.Forms.Button se2;
        private System.Windows.Forms.Button se4;
        private System.Windows.Forms.Button se3;
        private System.Windows.Forms.Button se5;
        private System.Windows.Forms.Button se10;
        private System.Windows.Forms.Button se9;
        private System.Windows.Forms.Button se8;
        private System.Windows.Forms.Button se7;
        private System.Windows.Forms.Button se6;
        private System.Windows.Forms.Button se15;
        private System.Windows.Forms.Button se14;
        private System.Windows.Forms.Button se13;
        private System.Windows.Forms.Button se12;
        private System.Windows.Forms.Button se11;
        private System.Windows.Forms.Button se20;
        private System.Windows.Forms.Button se19;
        private System.Windows.Forms.Button se18;
        private System.Windows.Forms.Button se17;
        private System.Windows.Forms.Button se16;
        private System.Windows.Forms.Button se25;
        private System.Windows.Forms.Button se24;
        private System.Windows.Forms.Button se23;
        private System.Windows.Forms.Button se22;
        private System.Windows.Forms.Button se21;

        private byte[] se;
    }
}